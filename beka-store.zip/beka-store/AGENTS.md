<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- Store pages live in `src/views/*` and are mounted by thin route files in `src/routes/*`; keep routing in TanStack routes (old `#/path` links are redirected in `__root.tsx`).
- The public catalog loads through the `getCatalog` server function (`src/lib/catalog.functions.ts`) + `catalogQueryOptions`, so SSR works without a session.
- Signed-in data (orders, top-ups, profiles, admin) is read from the browser client and protected by RLS; owner access comes only from `public.user_roles` via `is_owner()`, never from profile fields.
- Order prices are set by the `orders_set_amount` database trigger and money moves only inside `review_order` / `review_topup` / `place_wallet_order` (only wallet-paid orders deduct balance); never compute or write amounts or balances from the client.
- Receipt images go to the private `receipts` bucket and are shown to owners with short-lived signed URLs.
- Component styling was ported from the original store and uses the `brand-*`, `electric-*` and `surface` tokens defined in `src/styles.css`; add new colors there, not inline.
- Store owners are granted automatically from the private `owner_email_allowlist` table (trigger on confirmed auth users); add admin emails there instead of hand-inserting roles, so access applies whenever that account signs up.
