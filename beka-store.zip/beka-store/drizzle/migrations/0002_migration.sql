-- Price is always filled in by the orders_set_amount trigger; the default only lets the app omit it.
ALTER TABLE public.orders ALTER COLUMN amount_sdg SET DEFAULT 0;