import { supabase } from '@/lib/supabase';
import { lovable } from '@/integrations/lovable/index';
import { toE164 } from '@/lib/phone';

export async function signInWithGoogle(): Promise<void> {
  const result = await lovable.auth.signInWithOAuth('google', {
    redirect_uri: window.location.origin,
  });
  if (result.error) throw result.error;
}

export async function sendPhoneCode(localPhone: string): Promise<void> {
  const { error } = await supabase.auth.signInWithOtp({ phone: toE164(localPhone) });
  if (error) throw error;
}

export async function verifyPhoneCode(localPhone: string, token: string): Promise<void> {
  const { error } = await supabase.auth.verifyOtp({
    phone: toE164(localPhone),
    token,
    type: 'sms',
  });
  if (error) throw error;
}

export async function signInWithEmail(email: string, password: string): Promise<void> {
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
}

/** Returns true when the account is signed in right away, false when the email must be confirmed first. */
export async function signUpWithEmail(email: string, password: string, name: string): Promise<boolean> {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { name }, emailRedirectTo: `${window.location.origin}/account` },
  });
  if (error) throw error;
  return data.session !== null;
}

export async function signOutUser(): Promise<void> {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}
